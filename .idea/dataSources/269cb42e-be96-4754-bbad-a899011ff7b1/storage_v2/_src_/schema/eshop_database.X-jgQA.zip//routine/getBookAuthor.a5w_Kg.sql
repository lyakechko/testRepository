create
    definer = root@localhost procedure getBookAuthor(IN bookAuthor varchar(200), OUT book_name varchar(200))
begin
    select eshop_database.book.name
    into book_name
    from eshop_database.book
    where eshop_database.book.author = bookAuthor
    limit 1;
end;

